package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.AddmissionForm;

public interface addmissionformService {
 
	public void save(AddmissionForm addmissionform);
	
	public List<AddmissionForm> getAll();
	
	public void deleteById(int theId);
}
