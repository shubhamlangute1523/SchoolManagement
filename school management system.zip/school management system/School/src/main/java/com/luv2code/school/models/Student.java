package com.luv2code.school.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.el.parser.AstTrue;
import org.aspectj.weaver.tools.Trace;

@Entity
@Table(name = "Student")
public class Student {

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "parents_ID",referencedColumnName = "id")
	private Parent parents;
	
	@ManyToOne
	@JoinTable(
            name = "student_course",
            joinColumns = @JoinColumn(name = "Student_roll",referencedColumnName = "roll"),
            inverseJoinColumns = @JoinColumn(name = "course_id",referencedColumnName = "id")
     )
    private Course course;
	
	public Course getCourse() {
		return course;
	}
	
	public void setCourse(Course course) {
		this.course = course;
	}

	public Parent getParents() {
		return parents;
	}

	public void setParents(Parent parents) {
		this.parents = parents;
	}

	@Id
	private int roll;
	
	private String name;
	
	private String gender;
	
	private String dob;
	
	private String cast;
	
	private String Standard;

	public Student(int roll, String name, String gender, String dob, String cast, String standard) {
		super();
		this.roll = roll;
		this.name = name;
		this.gender = gender;
		this.dob = dob;
		this.cast = cast;
		Standard = standard;
	}

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getStandard() {
		return Standard;
	}

	public void setStandard(String standard) {
		Standard = standard;
	}

	public Student() {
		super();
	}
	
	
	
}
