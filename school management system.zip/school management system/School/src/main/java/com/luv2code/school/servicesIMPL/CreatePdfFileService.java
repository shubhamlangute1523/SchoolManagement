package com.luv2code.school.servicesIMPL;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.property.TextAlignment;
import com.luv2code.school.Repository.StudentRepository;
import com.luv2code.school.models.Student;

@Service
public class CreatePdfFileService {

	@Autowired
	private StudentRepository studentrepo;
	
	public Student findById(int theRoll) {
    Optional<Student> result = studentrepo.findById(theRoll);
		
		Student theStudent=null;
		if(result.isPresent())
		{
			theStudent = result.get();
		}
		else {
			throw new RuntimeException("Do not find Student id:"+theRoll);
		}
		return theStudent;
	}

	
	public Student createPdf(int therRoll) throws IOException {
	String filePath="C:/pdf/Bonafide.pdf";
	Optional<Student> result = studentrepo.findById(therRoll);
	
	Student theStudent=null;
	if(result.isPresent())
	{
		theStudent = result.get();
	}
	else {
	}
	

	try {
		PdfWriter writer = new PdfWriter(filePath);
		
		PdfDocument pdfDoc = new PdfDocument(writer);
     	pdfDoc.setDefaultPageSize(PageSize.A4.rotate());
     	
     	  
     	Border b1 = new DashedBorder(Color.GRAY,2);
		Document document =new Document(pdfDoc);
//		document.setBackgroundColor(Color.GREEN);
//		document.setBorder(b1);
		Paragraph p1= new Paragraph("Bonafide Certificate");
		p1.setFontSize(40);
		p1.setTextAlignment(TextAlignment.CENTER);
		p1.setBorderTop(b1);
		p1.setMarginTop(10);
		p1.setBold();
//		p1.setBorderBottom(b1);
		
		PdfFont font;
		
			font = PdfFontFactory.createFont(FontConstants.TIMES_BOLD);
			PdfFont	font2 = PdfFontFactory.createFont(FontConstants.TIMES_ITALIC);
			p1.setFont(font);
			Paragraph p2= new Paragraph("This is to certify  to Mr./Ms "+theStudent.getName()+" is a");
			Paragraph p3= new Paragraph(" Bonafide  student of our institute  studying in "+theStudent.getStandard()+" class");
			Paragraph p4= new Paragraph("Cast     "+theStudent.getCast()+"   Address   is  "+theStudent.getParents().getAddress());
			Paragraph p5= new Paragraph("Assigned Roll is "+theStudent.getRoll()+"    Date of Bith is  "+theStudent.getDob());
			Paragraph p6 = new Paragraph("Principal signature: ___________College Stamp___________");
			Paragraph p7 = new Paragraph("");
			p2.setFont(font2);
			p2.setFontSize(30);
			p2.setPaddingTop(20);
			p2.setPaddingLeft(20);
			p3.setFont(font2);
			p3.setFontSize(30);
		    p3.setPaddingTop(20);
		    p3.setPaddingLeft(50);
		    p4.setFont(font2);
			p4.setFontSize(30);
		    p4.setPaddingTop(20);
		    p4.setPaddingLeft(80);
		    p5.setFont(font2);
			p5.setFontSize(30);
			p5.setPaddingLeft(85);
		    p5.setPaddingTop(20);
		    p6.setFont(font2);
			p6.setFontSize(30);
		    p6.setPaddingTop(50);
		    p7.setPaddingTop(30);
//		    p6.setPaddingLeft(40);
//		    p6.setMarginBottom(40);
		    p7.setBorderBottom(b1);
		  
		
		document.add(p1);
		document.add(p2);
		document.add(p3);
		document.add(p4);
		document.add(p5);
		document.add(p6);
		document.add(p7);
		document.close();
				
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;
	}
}
