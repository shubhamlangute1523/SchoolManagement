package com.luv2code.school.servicesIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.vehicleRepository;
import com.luv2code.school.models.Vehicle;
import com.luv2code.school.services.vehicleService;
@Service
public class VehicleServiceIMPL implements vehicleService {

	@Autowired
	private vehicleRepository vehiclerepo;
	@Override
	public void save(Vehicle vehicle) {
	vehiclerepo.save(vehicle);
		}
	@Override
	public List<Vehicle> getAll() {
		// TODO Auto-generated method stub
		return vehiclerepo.findAll();
	}
	@Override
	public void deleteById(int theId) {
	vehiclerepo.deleteById(theId);
		
	}

}
