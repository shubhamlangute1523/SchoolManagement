package com.luv2code.school.servicesIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.ClassesRepository;
import com.luv2code.school.models.Classes;
import com.luv2code.school.services.ClassesService;
@Service
public class ClaseesServiceIMPL implements ClassesService {

	@Autowired
	private ClassesRepository classrepo;
	@Override
	public Classes save(Classes classes) {
    return classrepo.save(classes);
	}

	@Override
	public List<Classes> getAll() {
		// TODO Auto-generated method stub
		return classrepo.findAll();
	}

}
