package com.luv2code.school.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.luv2code.school.models.AddmissionForm;
import com.luv2code.school.models.Vehicle;
import com.luv2code.school.models.contact;
import com.luv2code.school.services.addmissionformService;
import com.luv2code.school.services.contactService;
import com.luv2code.school.services.vehicleService;

@Controller
@RequestMapping("/static")
public class staticController {
	
	@Autowired
	private addmissionformService addmissionform;
	
	@Autowired
	private contactService contactService;
	
	@Autowired
	private vehicleService vehicleservice;

	@GetMapping("/about")
	public String aboutpage() {
		return "about";
	}
	@GetMapping("/contact")
	public String Contactpage(Model theModel) {
		theModel.addAttribute("contact",new contact());
		return "contact";
	}
	@GetMapping("/teacher")
	public String teacherpage() {
		return "teacher";
	}
	@GetMapping("/vehicle")
	public String Vehiclepage(Model theModel) {		
		theModel.addAttribute("newVehicle",new Vehicle());
		return "vehicle";
	}
	@GetMapping("/home")
	public String Homepage() {
		return "index";
	}
	@GetMapping("/applyadd")
	public String applyAdd(Model theModel) {
		
		theModel.addAttribute("newAddmission",new AddmissionForm());
		return "AddmissionForm/addmissionform";
	}
	@PostMapping("/addmissiondata")
	public String applyAdd(@ModelAttribute AddmissionForm addmsn) {		
		addmissionform.save(addmsn);
		return "success";
	}
	@PostMapping("/contactresult")
	public String contacts(@ModelAttribute contact con) {		
		contactService.savecon(con);
		return "success";
	}
	@PostMapping("/vehicleform")
	public String vehicleform(@ModelAttribute Vehicle vehicle) {		
		vehicleservice.save(vehicle);
		return "success";
	}
	
	
}
