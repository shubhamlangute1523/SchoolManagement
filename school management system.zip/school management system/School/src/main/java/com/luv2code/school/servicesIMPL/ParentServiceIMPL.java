package com.luv2code.school.servicesIMPL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.ParentRepository;
import com.luv2code.school.models.Parent;
import com.luv2code.school.services.ParentService;
@Service
public class ParentServiceIMPL implements ParentService {

	@Autowired
	private ParentRepository parentrepo;
	@Override
	public Parent saveParent(Parent theParent) {
	return parentrepo.save(theParent);
		
	}
	@Override
	public List<Parent> getAll() {
		// TODO Auto-generated method stub
		return parentrepo.findAll();
	}

}
