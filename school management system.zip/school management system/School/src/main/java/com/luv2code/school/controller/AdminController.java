package com.luv2code.school.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.school.models.AddmissionForm;
import com.luv2code.school.models.Vehicle;
import com.luv2code.school.models.contact;
import com.luv2code.school.services.addmissionformService;
import com.luv2code.school.services.contactService;
import com.luv2code.school.services.vehicleService;

@Controller
public class AdminController {
     
	@Autowired
	private addmissionformService addmissionforms;
	
	@Autowired
	private contactService contactService;
	
	@Autowired
	private vehicleService vehicleService;
	
	@GetMapping("/admin")
	public String adminHome() {
		return "/admin/Home";		
	}
	
	@GetMapping("/access-denied")
	public String loginError() {
		return "/admin/error";		
	}
	@GetMapping("admin/addmissionformlist")
	public String addmissionForms(Model theModel) {
		
		List<AddmissionForm> addmissionformsList=addmissionforms.getAll();
		theModel.addAttribute("addmissionform",addmissionformsList);
		return "AddmissionForm/addmissionFormList";
		
	}
	@GetMapping("admin/addmissionformlist/delete")
	public String deleteAddmissionform(@RequestParam("id") int theId)
	{
		addmissionforms.deleteById(theId);
		return "redirect:/admin/addmissionformlist";
		
	}
	@GetMapping("admin/contactformlist")
	public String contactForms(Model theModel) {
		
		List<contact> contactformsList=contactService.getAll();
		theModel.addAttribute("contactform",contactformsList);
		return "contactFormList";
		
	}
	
	@GetMapping("admin/contactformlist/delete")
	public String contactFormsdelete(@RequestParam("id") int theId) {
		contactService.delteById(theId);
		return "redirect:/admin/contactformlist";
		
	}
	@GetMapping("admin/vehicleformlist")
	public String vehicleForms(Model theModel) {
		
//		List<contact> contactformsList=contactService.getAll();
		
		List<Vehicle> vehicles = vehicleService.getAll();
		theModel.addAttribute("vehicles",vehicles);
		return "vehicleFormList";
		
	}
	
	@GetMapping("admin/vehicleformlist/delete")
	public String vehicleFormsdelete(@RequestParam("id") int theId) {
		vehicleService.deleteById(theId);
		return "redirect:/admin/vehicleformlist";		
	}
	
	
	
}
