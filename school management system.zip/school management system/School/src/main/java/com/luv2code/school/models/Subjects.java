package com.luv2code.school.models;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "subjects")
public class Subjects {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
		
	private String name;
	
	@ManyToMany
	@JoinColumn(name = "course_id")
	Set<Course> course=new HashSet<>();

	@ManyToOne(cascade = CascadeType.ALL)
	private Teacher teacher;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Set<Course> getCourse() {
		return course;
	}

	public void setCourse(Set<Course> course) {
		this.course = course;
	}

	public Subjects(int id, String name, Set<Course> course) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
	}

	public Subjects() {
		super();
	}
	
	
}
