package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.contact;

public interface contactService {

	public void savecon(contact theContact);
	
	public List<contact> getAll();
	
	public void delteById(int theId);
}
