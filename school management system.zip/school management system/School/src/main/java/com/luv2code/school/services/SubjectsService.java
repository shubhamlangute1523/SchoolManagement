package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Subjects;

public interface SubjectsService {

	public Subjects save(Subjects theSubjects);
	
	public List<Subjects> getAll();
	
	public Subjects findById(int theId);
	
	public void deleteById(int theId);
}
