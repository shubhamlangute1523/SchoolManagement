package com.luv2code.school.controller;

import java.util.List;

import javax.security.auth.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.school.models.Course;
import com.luv2code.school.models.Subjects;
import com.luv2code.school.services.SubjectsService;
import com.luv2code.school.services.courseService;
import com.luv2code.school.servicesIMPL.SubjectServiceIMPL;

@Controller
@RequestMapping("admin/teacher/subjects")
public class SubjectsController {

	@Autowired
	private SubjectsService subjectsService;
	
	@Autowired
	private courseService courseService;
	@GetMapping("/add")
	public String addSubjects(Model theModel) {
	    theModel.addAttribute("newSubjects", new Subjects());
		List<Course> courses=courseService.getcourses();
		theModel.addAttribute("courses",courses);
		return "teacher/addSubjects";
	}
	
	@PostMapping("/addSubjects")
	public String addsubConfirm(@ModelAttribute Subjects subjects) {
		subjects.setCourse(subjects.getCourse());
		subjectsService.save(subjects);
		return "redirect:/admin/teacher/subjects/list";
	}
	
	@GetMapping("/list")
	public String SubjectList(Model theModel)
	{
		List<Subjects> subjects = subjectsService.getAll();
		theModel.addAttribute("subjects",subjects);
		return "teacher/SubjectsList";	
		
	}
	@GetMapping("/edit")
	public String EditSub(@RequestParam("SubjectId") int theId,Model theModel) {
		Subjects subjects= subjectsService.findById(theId);		
		theModel.addAttribute("newSubjects",subjects);
		List<Course> courses=courseService.getcourses();
		theModel.addAttribute("courses",courses);
		return "teacher/addSubjects";
		
	}
	@GetMapping("/delete")
	public String DeleteCourse(@RequestParam("SubjectId") int theId,Model theModel) {
		subjectsService.deleteById(theId);
		return "redirect:/admin/teacher/subjects/list";
		
	}
	
	

}
