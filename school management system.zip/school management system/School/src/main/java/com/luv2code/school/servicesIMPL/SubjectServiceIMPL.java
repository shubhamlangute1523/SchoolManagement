package com.luv2code.school.servicesIMPL;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.SubjectRepository;
import com.luv2code.school.models.Subjects;
import com.luv2code.school.services.SubjectsService;
@Service
public class SubjectServiceIMPL implements SubjectsService {

	@Autowired
	private SubjectRepository subjectRepository;
	
	@Override
	public Subjects save(Subjects theSubjects) {
		// TODO Auto-generated method stub
		return subjectRepository.save(theSubjects);
	}

	@Override
	public List<Subjects> getAll() {
		// TODO Auto-generated method stub
		return subjectRepository.findAll();
	}

	@Override
	public Subjects findById(int theId) {
		Optional<Subjects> result = subjectRepository.findById(theId);
		Subjects theSubjects=null;
		if(result.isPresent()) {
			theSubjects=result.get();
		}
		else {
			throw new RuntimeException("Subject not found");
		}
		return theSubjects;
	}

	@Override
	public void deleteById(int theId) {
 subjectRepository.deleteById(theId);
		
	}

}
