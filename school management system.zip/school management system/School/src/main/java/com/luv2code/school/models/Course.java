package com.luv2code.school.models;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionId;

@Entity
@Table(name = "course")
public class Course {

	
		@ManyToMany(mappedBy = "course")
		Set<Subjects> subjects = new HashSet<>();
	
	    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL)
	    private Set<Student> students;
		
	  public Set<Student> getStudents() {
			return students;
		}
	  
	  
	  

		public void setStudents(Set<Student> students) {
			this.students = students;
		}

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String name;
	
	
	private String fees;
	

	private String duration;

	public Course() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFees() {
		return fees;
	}

	public void setFees(String fees) {
		this.fees = fees;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Course(int id, String name, String fees, String duration) {
		super();
		this.id = id;
		this.name = name;
		this.fees = fees;
		this.duration = duration;
	}

	public Course(String name, String fees, String duration) {
		super();
		this.name = name;
		this.fees = fees;
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", fees=" + fees + ", duration=" + duration + "]";
	}
	
	
}
