package com.luv2code.school.servicesIMPL;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.core.EntityInformation;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.CourseRepository;
import com.luv2code.school.models.Course;
import com.luv2code.school.services.courseService;
@Service
public class courseServiceIMPL implements courseService {

	@Autowired
	private CourseRepository courseRepository;
	@Override
	public void save(Course theCourse) {
		// TODO Auto-generated method stub		
       courseRepository.save(theCourse);
	}

	@Override
	public void delete(int thId) {
		// TODO Auto-generated method stub
      courseRepository.deleteById(thId);;
	}

	@Override
	public Course findById(int theId) {
		Optional <Course> theCourse = courseRepository.findById(theId);
		Course theCourse1=null;
		if(theCourse.isPresent()) {
			theCourse1=theCourse.get();
		}
		else {
			throw new RuntimeException("Course not found");
		}
		
		return theCourse1;
	}

	@Override
	public List<Course> getcourses() {
		// TODO Auto-generated method stub
		return courseRepository.findAll();
	}

}
