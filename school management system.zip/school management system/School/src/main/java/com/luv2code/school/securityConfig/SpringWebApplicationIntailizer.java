package com.luv2code.school.securityConfig;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringWebApplicationIntailizer extends AbstractSecurityWebApplicationInitializer {

}
