package com.luv2code.school.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.luv2code.school.models.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Integer> {
   
}
