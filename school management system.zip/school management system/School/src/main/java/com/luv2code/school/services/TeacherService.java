package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Teacher;

public interface TeacherService {
   public void save(Teacher teacher);
   
   public Teacher findByid(int theId);
   
   public void deleteById(int theId);
   
   List<Teacher> getTeachers();
}
