package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Vehicle;

public interface vehicleService {

	
	public void save(Vehicle vehicle);
	
	public List<Vehicle> getAll();
	
	public void deleteById(int theId);

}
