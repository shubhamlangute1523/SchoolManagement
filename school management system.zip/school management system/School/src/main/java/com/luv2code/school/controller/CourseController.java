package com.luv2code.school.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.school.models.Course;
import com.luv2code.school.services.courseService;

@Controller
@RequestMapping("admin/courses")
public class CourseController {

	@Autowired
	private courseService courseservice;
	
	@GetMapping("/add")
	public String addCourse(Model theModel) {
		theModel.addAttribute("course",new Course());		
		return "course/addCourse";
		
	}
	@PostMapping("/addCourse")
	public String addCourse(@ModelAttribute Course theCourse,Model theModel) {		
		courseservice.save(theCourse);
//		theModel.addAttribute("course",new Course());		
		return "redirect:/admin/courses/list";
		
	}
	@GetMapping("/list")
	public String ListCourse(Model theModel)
	{
		List<Course> courses = courseservice.getcourses();
		
		theModel.addAttribute("courses",courses);
		return "course/courseList";		
	}
	@GetMapping("/edit")
	public String EditCourse(@RequestParam("courseId") int theId,Model theModel) {
		Course theCourse= courseservice.findById(theId);		
		theModel.addAttribute("course",theCourse);
		return "course/addCourse";
		
	}
	@GetMapping("/delete")
	public String DeleteCourse(@RequestParam("courseId") int theId,Model theModel) {
		courseservice.delete(theId);
		return "redirect:/admin/courses/list";
		
	}
	
	
	
}
