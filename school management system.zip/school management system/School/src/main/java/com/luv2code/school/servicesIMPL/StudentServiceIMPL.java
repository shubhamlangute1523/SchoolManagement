package com.luv2code.school.servicesIMPL;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.StudentRepository;
import com.luv2code.school.models.Student;
import com.luv2code.school.services.StudentService;
@Service
public class StudentServiceIMPL implements StudentService {

	@Autowired
	private StudentRepository studentrepo;
	
	@Override
	public void saveStudent(Student theStudent) {
		studentrepo.save(theStudent);	
	}

	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		return studentrepo.findAll();
	}

	@Override
	public Student findById(int theRoll) {
    Optional<Student> result = studentrepo.findById(theRoll);
		
		Student theStudent=null;
		if(result.isPresent())
		{
			theStudent = result.get();
		}
		else {
			throw new RuntimeException("Do not find employee id:"+theRoll);
		}
		return theStudent;
	}

	@Override
	public void deleteById(int theRoll) {
		studentrepo.deleteById(theRoll);		
	}

}
