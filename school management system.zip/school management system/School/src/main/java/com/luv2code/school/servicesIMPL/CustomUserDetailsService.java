package com.luv2code.school.servicesIMPL;

import javax.management.loading.PrivateClassLoader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.UserRepository;
import com.luv2code.school.models.User;
import com.luv2code.school.securityConfig.CustomUserDetails;
@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
    private UserRepository userrepo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       User user= userrepo.findByusername(username);
       if(user == null) {
    	   throw new UsernameNotFoundException("User Not Found");
       }
		return new CustomUserDetails(user);
	}
}
