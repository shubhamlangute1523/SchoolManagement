package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Course;

public interface courseService {
     
	public void save(Course theCourse);
	
	
	
	public Course findById(int theId);
	public List<Course> getcourses();

	void delete(int thId);
	
}
