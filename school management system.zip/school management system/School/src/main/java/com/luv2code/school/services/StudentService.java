package com.luv2code.school.services;

import java.util.List;
import java.util.Optional;

import com.luv2code.school.models.Student;

public interface StudentService {
   
	public void saveStudent(Student theStudent);
	
	public List<Student> getAll();
	
	public Student findById(int theRoll);
	
	public void deleteById(int theRoll);
}
