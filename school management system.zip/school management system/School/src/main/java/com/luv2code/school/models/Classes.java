package com.luv2code.school.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Classes")
public class Classes {

	@OneToOne(mappedBy = "classes")
	private Teacher teacher;
		
	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String class_name;
	
	private String student_strength;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClass_name() {
		return class_name;
	}

	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}

	public Classes(int id, String name, String student_strength) {
		super();
		this.id = id;
		this.class_name = name;
		this.student_strength = student_strength;
	}

	public String getStudent_strength() {
		return student_strength;
	}

	public void setStudent_strength(String student_strength) {
		this.student_strength = student_strength;
	}

	public Classes() {
		super();
	}
	
	
	
}
