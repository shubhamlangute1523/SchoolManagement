package com.luv2code.school.servicesIMPL;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.TeacherRepository;
import com.luv2code.school.models.Teacher;
import com.luv2code.school.services.TeacherService;
@Service
public class TeacherServiceIMPL implements TeacherService {

	@Autowired
	private TeacherRepository teacherrepo;
	
	@Override
	public void save(Teacher teacher) {
      teacherrepo.save(teacher);
	}

	@Override
	public Teacher findByid(int theId) {

		Optional<Teacher> result =teacherrepo.findById(theId);
		
		Teacher theTeacher=null;
		if(result.isPresent())
		{
			theTeacher=result.get();
		}
		else
			throw new RuntimeException("Teacher not found");
		return theTeacher;
	}

	@Override
	public void deleteById(int theId) {
		// TODO Auto-generated method stub
		teacherrepo.deleteById(theId);
	}

	@Override
	public List<Teacher> getTeachers() {
		// TODO Auto-generated method stub
		return teacherrepo.findAll();
	}

}
