package com.luv2code.school.servicesIMPL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luv2code.school.Repository.AddmissionRepo;
import com.luv2code.school.models.AddmissionForm;
import com.luv2code.school.services.addmissionformService;
@Service
public class AddmissionFormServiceIMPL implements addmissionformService {

	@Autowired
	private AddmissionRepo addmissionrepo;
	@Override
	public void save(AddmissionForm addmissionform) {
		addmissionrepo.save(addmissionform);
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<AddmissionForm> getAll() {
		// TODO Auto-generated method stub
		return addmissionrepo.findAll();
	}
	@Override
	public void deleteById(int theId) {
     addmissionrepo.deleteById(theId);		
	}

}
