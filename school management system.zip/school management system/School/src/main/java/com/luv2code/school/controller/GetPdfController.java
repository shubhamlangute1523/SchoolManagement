package com.luv2code.school.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.luv2code.school.servicesIMPL.CreatePdfFileService;

@Controller
public class GetPdfController {

	
	private CreatePdfFileService createPdfFileService;
	
	@Autowired
	public GetPdfController(CreatePdfFileService createPdfFileService) {
		super();
		this.createPdfFileService = createPdfFileService;
	}


	@GetMapping("/pdfFile")
	public String getpdf() {
		return "getBonafidepdf";
	}
	
	@GetMapping("/createPdf")
	public String pdfFile() throws IOException {
//		createPdfFileService.createPdf();
		return "redirect:/pdfFile";
	}
}
