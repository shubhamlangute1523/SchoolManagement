package com.luv2code.school.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.luv2code.school.models.AddmissionForm;
@Repository
public interface AddmissionRepo extends JpaRepository<AddmissionForm, Integer> {

}
