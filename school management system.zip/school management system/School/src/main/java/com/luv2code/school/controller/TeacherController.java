package com.luv2code.school.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.school.models.Classes;
import com.luv2code.school.models.Subjects;
import com.luv2code.school.models.Teacher;
import com.luv2code.school.services.ClassesService;
import com.luv2code.school.services.SubjectsService;
import com.luv2code.school.services.TeacherService;

@Controller
@RequestMapping("admin/teacher")
public class TeacherController {

	@Autowired
	private TeacherService teacherService;
	
	@Autowired
	private ClassesService classesService;
	
	@Autowired
	private SubjectsService subjectsService;
	
	
	@GetMapping("/add")
	public String getTeacherForm(Model theModel)
	{
		Model theModel2;
		theModel.addAttribute("newTeacher",new Teacher());
		theModel.addAttribute("newClasses",new Classes());
		return "teacher/AddTeacherForm";
	}
	
	@PostMapping("/addTeacher")
	public String addTeacherConfirm(@ModelAttribute Teacher teacher,@ModelAttribute Classes classes,Model theModel)
	{
		Classes temp=classesService.save(classes);
		teacher.setClasses(temp);	
		teacherService.save(teacher);
		theModel.addAttribute("newTeacher",new Teacher());
		theModel.addAttribute("newClasses",new Classes());
		return "redirect:/admin/teacher/teacherShow";
	
	}
	
	@GetMapping("/teacherShow")
	public String showTeacher(Model theModel) {
		
		List<Teacher> teachers = teacherService.getTeachers();
		
		theModel.addAttribute("teachers",teachers);
		
		
		return "teacher/TeacherList";
		
	}
	
	@GetMapping("/edit")
	public String showFormForUpdate(@RequestParam("TeacherId") int theId,Model theModel) {
		Teacher teacher = teacherService.findByid(theId);
		Classes classes = teacher.getClasses();
		theModel.addAttribute("newTeacher",teacher);
		theModel.addAttribute("newClasses",classes);		
		return "teacher/AddTeacherForm";		
	}
	@GetMapping("/delete")
	public String showDelete(@RequestParam("TeacherId") int theId,Model theModel) {
		Teacher teacher = teacherService.findByid(theId);
		teacherService.deleteById(theId);
		return "redirect:/admin/teacher/teacherShow";		
	}
	@GetMapping("/assignSubjects")
    public String assignSub(Model theModel)
	{
		List<Teacher> teachers= teacherService.getTeachers();
		
		List<Subjects> subjects = subjectsService.getAll();
		
 	    theModel.addAttribute("teachers",teachers);
	
		theModel.addAttribute("subjects",subjects);
		
		theModel.addAttribute("newTeacher",new Teacher());
		theModel.addAttribute("newSubject",new Subjects());
    	return "teacher/AssignSubjects";
		
}
	@PostMapping("/addSubjectsteachers")
    public String assignSubConfirm(@ModelAttribute Teacher theTeacher,Model theModel)
	{
		Teacher theTeacher1=teacherService.findByid(theTeacher.getId());
	    theTeacher1.setSubjects(theTeacher.getSubjects()); 
//	    theTeacher1.setAge(theTeacher.getAge());
	    teacherService.save(theTeacher1);
        List<Teacher> teachers= teacherService.getTeachers();
	 	
		List<Subjects> subjects1 = subjectsService.getAll();
		
		theModel.addAttribute("teachers",teachers);

		theModel.addAttribute("subjects",subjects1);
		
	     theModel.addAttribute("newTeacher",new Teacher());
	     
	     theModel.addAttribute("newSubject",new Subjects());
		return "teacher/AssignSubjects";
			}
}
