package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Parent;
import com.luv2code.school.models.Student;

public interface ParentService {
	public Parent saveParent(Parent theParent);
	
	public List<Parent> getAll();
}
