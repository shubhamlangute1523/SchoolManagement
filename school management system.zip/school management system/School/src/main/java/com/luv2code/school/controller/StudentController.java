package com.luv2code.school.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.context.Theme;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luv2code.school.models.Course;
import com.luv2code.school.models.Parent;
import com.luv2code.school.models.Student;
import com.luv2code.school.services.ParentService;
import com.luv2code.school.services.StudentService;
import com.luv2code.school.services.courseService;
import com.luv2code.school.servicesIMPL.CreatePdfFileService;

@Controller
@RequestMapping("/admin/student")
public class StudentController {
   
	@Autowired
	private StudentService studentservice;
	
	@Autowired
	private CreatePdfFileService createPdfFileService;
	@Autowired
	private courseService courseService;
	@Autowired
	private ParentService parentSerice;
	@GetMapping("/add")
	public String addStudentForm(Model theModel) {
		theModel.addAttribute("newStudent",new Student());
		
		theModel.addAttribute("newParent",new Parent());
		
		return "student/StudentForm";
	}
	
	@PostMapping("/addStudent")
	public String AddStudent(@ModelAttribute Student theStudent,@ModelAttribute Parent theParent,Model theModel) {
		
		Parent temp=parentSerice.saveParent(theParent);
		theStudent.setParents(temp);
		studentservice.saveStudent(theStudent);
		
        theModel.addAttribute("newStudent",new Student());
		
		theModel.addAttribute("newParent",new Parent());
		
		return "student/StudentForm";
		
	}
	@GetMapping("Studentshow")
    public String STHome(Model model){
        List<Student> student =studentservice.getAll();
//        List<Parent> parent = parentSerice.getAll();        
        model.addAttribute("student",  student);  
//        model.addAttribute("parent",  parent); 
        return "student/StudentList";
    }
	@GetMapping("/edit")
	public String ShowFormForUpdate(@RequestParam("studentRoll") int theRoll,Model theModel)
	{
//		Employee theEmployee = employeeservice.findById(theId);
		Student theStudent=studentservice.findById(theRoll);
		theModel.addAttribute("newStudent", theStudent);
		Parent parent = theStudent.getParents();
		theModel.addAttribute("newParent", parent);
		return "student/StudentForm";
	}
	@GetMapping("/delete")
	public String Delete(@RequestParam("studentRoll") int theRoll,Model theModel)
	{
		
		try {
		Student theStudent=studentservice.findById(theRoll);
		}
		catch (Exception e) {
			return "redirect:Studentshow";
		}
//		Employee theEmployee = employeeservice.findById(theId);
		studentservice.deleteById(theRoll);
        
		return "redirect:Studentshow";
	}
	@GetMapping("/searchBonafide")
	public String studentBonafide(Model theModel)
	{
//		List<Student> theStudent=studentservice.getAll();
		
		
		theModel.addAttribute("Bonafide",new Student());
		return "Bonafide/searchBonafide";
		

	}
	@PostMapping("/DisplayBonafide")
	public String DisplayBonafide(@RequestParam("roll") int theRoll,Model theModel) throws IOException
	{
		Student theStudent = createPdfFileService.createPdf(theRoll);
		
		theModel.addAttribute("student", theStudent);
		return "redirect:/admin";
		
	}
	@GetMapping("/assignCourse")
	public String assigncourse(Model theModel) {
		List<Course> course = courseService.getcourses();
		
		List<Student> students=studentservice.getAll();
		
		theModel.addAttribute("course",course);
		theModel.addAttribute("students",students);
		
		theModel.addAttribute("newStudent",new Student());
		
		theModel.addAttribute("newCourse",new Course());
		return "course/assigncourse";
		
	}
	@PostMapping("/confirmAssign")
	public String assignCourseConfirm(@ModelAttribute Student theStudent,@ModelAttribute Course thCourse,Model theModel) {
		
		Student student1=studentservice.findById(theStudent.getRoll());
		
		Course courses= courseService.findById(thCourse.getId());
		
		student1.setCourse(courses);
		studentservice.saveStudent(student1);
        List<Course> course = courseService.getcourses();
		
		List<Student> students=studentservice.getAll();
		
		theModel.addAttribute("course",course);
		theModel.addAttribute("students",students);
		
		theModel.addAttribute("newStudent",new Student());
		
		theModel.addAttribute("newCourse",new Course());
		return "course/assigncourse";
		
		
		
	}
}
