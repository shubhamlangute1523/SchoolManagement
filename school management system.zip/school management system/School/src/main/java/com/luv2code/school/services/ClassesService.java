package com.luv2code.school.services;

import java.util.List;

import com.luv2code.school.models.Classes;

public interface ClassesService {

	public Classes save(Classes classes);
	
	List<Classes> getAll();
	
}
