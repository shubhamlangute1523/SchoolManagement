-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2022 at 07:50 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schooldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmission_form`
--

CREATE TABLE `addmission_form` (
  `id` int(11) NOT NULL,
  `query` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `applystd` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `hobbies` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `studentage` int(11) NOT NULL,
  `studentname` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addmission_form`
--

INSERT INTO `addmission_form` (`id`, `query`, `address`, `applystd`, `dob`, `email`, `gender`, `hobbies`, `mobileno`, `parentname`, `pincode`, `studentage`, `studentname`) VALUES
(1, 'No', 'Phaltan', '2nd', '18,June,2007', 'aniket123@gmail.com', 'Male', 'playing', '9958573893', 'suraj raut', '415523', 14, 'Aniket Raut');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `student_strength` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `student_strength`) VALUES
(1, 'it 2nd', '80'),
(2, 'entc 1st', '50');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `email`, `message`, `mobile`, `name`) VALUES
(2, 'Shubhamlangute1523@gmail.com', 'i want to take a addmission', '9975378321', 'Shubham Langute');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `fees` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `duration`, `fees`, `name`) VALUES
(1, '3 years', '20000/-', 'B tech'),
(2, '2 years', '30000/-', 'bca'),
(3, '2 years', '40000/-', 'BBA');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mno` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `mother_name`, `address`, `father_name`, `mno`) VALUES
(1, 'anita', 'Phaltan', 'mahadev langute', '9975378321'),
(2, 'smita', 'Phaltan', 'rahul kunjir', '9975378321'),
(3, 'Aparna', 'Baramati', 'Ganesh Deshmukh', '987869575'),
(4, 'Savita', 'Karjat Maharastra', 'Rajendra Newase', '8586878959');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `roll` int(11) NOT NULL,
  `standard` varchar(255) DEFAULT NULL,
  `cast` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `parents_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`roll`, `standard`, `cast`, `dob`, `gender`, `name`, `parents_id`) VALUES
(12, '2nd', 'open', '22/02/2009', 'male', 'Shubham Langute', 1),
(33, '2nd', 'open', '22/02/2009', 'male', 'ketan kunjir', 2),
(18, '2nd', 'open', '04/03/2002', 'male', 'Suraj Ganesh Deshmukh', 3),
(10, '6th', 'open', '30/12/2003', 'male', 'Dattatray Rajendra newase', 4);

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `roll` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_course`
--

CREATE TABLE `student_course` (
  `course_id` int(11) DEFAULT NULL,
  `student_roll` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_course`
--

INSERT INTO `student_course` (`course_id`, `student_roll`) VALUES
(2, 33);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `teacher_id`) VALUES
(1, 'java', NULL),
(3, 'Php', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects_course`
--

CREATE TABLE `subjects_course` (
  `subjects_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects_course`
--

INSERT INTO `subjects_course` (`subjects_id`, `course_id`) VALUES
(1, 1),
(1, 2),
(3, 1),
(3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `qualification`, `age`, `designation`, `name`, `class_id`) VALUES
(1, 'B tech', '13', 'Manager', 'rahul yadav', 1),
(2, 'B tech', '56', 'Manager', 'chirag meher', 2);

-- --------------------------------------------------------

--
-- Table structure for table `teachers_subjects`
--

CREATE TABLE `teachers_subjects` (
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers_subjects`
--

INSERT INTO `teachers_subjects` (`teacher_id`, `subject_id`) VALUES
(2, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `password`, `role`, `username`) VALUES
(4, '$2y$10$p.lb/lvZrK9FsXkVevc4Yu.Y4JQTim2cP8jHB221i.zusH3fVMROm', 'TEACHER', 'sk'),
(3, '$2y$10$WRuryrAJbCC1lTM26Dz6sOgEg2DwwNxF2sp25W6MrdMSs2oLw1ZkK', 'ADMIN', 'dk'),
(5, '$2a$12$I43et5A/KrOj3tXUi2muxegUHtYFET29Ptsd.J7ZFio5Nzz/Osri2', 'TEACHER', 'anil123\r\n'),
(6, '$2a$10$17Tr4QK.6lPCiDuvUiTMteSqjqf2v4Og4gYCagmTdsFENuMdhIONi', 'ADMIN', 'suraj123'),
(7, '$2a$10$MvoXE1F.llESgcStLxXkju68jrBRwJF5C0WpF2/dB4JjYtpoi9ak2', 'TEACHER', 'anil@123');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(11) NOT NULL,
  `distance` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `standard` varchar(255) DEFAULT NULL,
  `studentname` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `distance`, `email`, `mobile`, `parentname`, `standard`, `studentname`) VALUES
(1, '8km', 'Shubhamlangute1523@gmail.com', '9975378321', 'Mahadev Langute', '8th', 'Shubham Langute');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmission_form`
--
ALTER TABLE `addmission_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`roll`),
  ADD KEY `FKns7vvfu32thkpedj7kir5iv23` (`parents_id`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_course`
--
ALTER TABLE `student_course`
  ADD PRIMARY KEY (`student_roll`),
  ADD KEY `FKejrkh4gv8iqgmspsanaji90ws` (`course_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK3csfetmomyye6tk45s4vb1e7v` (`teacher_id`);

--
-- Indexes for table `subjects_course`
--
ALTER TABLE `subjects_course`
  ADD PRIMARY KEY (`subjects_id`,`course_id`),
  ADD KEY `FKhhxxgee7f1248yyiashyu3brq` (`course_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKesed36ixw8ngb1nf1k71q51ty` (`class_id`);

--
-- Indexes for table `teachers_subjects`
--
ALTER TABLE `teachers_subjects`
  ADD PRIMARY KEY (`teacher_id`,`subject_id`),
  ADD UNIQUE KEY `UK_50kfocbnqnrpe354fyckwgoyy` (`subject_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addmission_form`
--
ALTER TABLE `addmission_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
